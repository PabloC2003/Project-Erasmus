//#ifndef DRIVER_HPP_INCLUDED
//#define DRIVER_HPP_INCLUDED

#include <string>
#include <iostream>

using namespace std;

class Driver{
    protected:
    string name, nationality;
    float experience; //experience level in elite years 

    public:
    //constructor
    Driver(string name, string nationality, float experience);
    //setters
    void setName (string name);
    void setNationality (string nationality);
    void setExperience (float experience);
    void displayDriverInfo();
    //getters
    string getName ();
    string getNationality ();
    float getExperience ();

    //virtual ~Driver() {}
    float skillFactor();
};
//#endif
