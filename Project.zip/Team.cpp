#include "Team.hpp"

//constructor
Team::Team(string teamname): teamname(teamname){}

//setters
void Team::setTeamname(string teamname){
    this->teamname=teamname;
}
//getters
string Team::getTeamname(){
    return teamname;
}

void Team::displayTeamInfo() {
    cout<<"-------------------------"<<endl;
    cout << "Team: " << teamname <<endl;
    }