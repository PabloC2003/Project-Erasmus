#ifndef DRIVER_HPP_INCLUDED
#define DRIVER_HPP_INCLUDED

#include <string>
#include <iostream>

using namespace std;

class Car{
    protected:
    string tires, wings;
    float power;

    public:
    //construcor
    Car(string tires, string wings, float power);
    //setters
    void setTires (string tires);
    void setWings (string wings);
    void setPower (float power);
    void displayCarInfo();
    //getters
    string getTires ();
    string getWings ();
    float getPower ();
    float getPerformanceFactor();
};

#endif