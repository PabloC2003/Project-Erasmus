#ifndef TEAM_HPP
#define TEAM_HPP

#include <string>
#include <iostream>

using namespace std;

class Team{
    private:
    string teamname; //brand

    public:
    //constructor
    Team(string teamname);
    //setters
    void setTeamname (string teamname);
    void displayTeamInfo();
    //getters
    string getTeamname ();

};
#endif