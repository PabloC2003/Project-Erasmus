#ifndef WEATHER_HPP_INCLUDED
#define WEATHER_HPP_INCLUDED

#include <string>
#include <iostream>

using namespace std;

class Weather{
    private:
    string condition;
    float temperature;

    public:
    //constructor
    Weather(string condition, float temperature);
    //setters
    void setCondition (string condition);
    void setTemperature( float temperature);
    void displayWeatherInfo();
    //getters
    string getCondition();
    float getTemperature();
    float impactOnSpeed();
};
#endif