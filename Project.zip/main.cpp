#include <iostream>
#include <vector>
#include <string>

#include "Track.hpp"
#include "Car.hpp"
#include "Driver.hpp"
#include "Weather.hpp"
#include "Team.hpp"

using namespace std;

class Leaderboard {
private:
    vector<pair<string, float>> standings;

public:
    void addResult(const string& teamName, float time) {
        standings.emplace_back(teamName, time);
    }

    void displayLeaderboard() {
        cout<<"-------------------------"<<endl;
        cout << "------- Leaderboard -------"<<endl;
        for (const auto& entry : standings) {
            cout << "Team: " << entry.first << ", Time: " << entry.second <<" minutes"<<endl;
        }
    }
};

int main(){
    //objects
    Track track("Monaco", 3.f, 50);
    Weather weather("Rainy", 25.0f);

    Driver driver1("Lewis Hamilton", "British", 15);
    Car car1("Slick", "Low-Drag", 1000);

    Driver driver2("Fernando Alonso", "Spain", 20);
    Car car2("Slick", "Low-Drag", 1000);

    Team team1("Mercedes");
    Team team2("RedBull");


    //Initial information
    track.displayTrackInfo();
    weather.displayWeatherInfo();

    team1.displayTeamInfo();
    driver1.displayDriverInfo();
    car1.displayCarInfo();

    team2.displayTeamInfo();
    driver2.displayDriverInfo();
    car2.displayCarInfo();
    
    //Calculations
    float totalDistance = track.getTotalDistance();

    float speedFactor1 = car1.getPerformanceFactor() * driver1.skillFactor() * weather.impactOnSpeed();
    float totalTime1 = totalDistance / speedFactor1;

    float speedFactor2 = car2.getPerformanceFactor() * driver2.skillFactor() * weather.impactOnSpeed();
    float totalTime2 = totalDistance / speedFactor2;

    //Show results
   
Leaderboard leaderboard;
        leaderboard.addResult(team1.getTeamname(), totalTime1/60);
        leaderboard.addResult(team2.getTeamname(), totalTime2/60);
        leaderboard.displayLeaderboard();
        
    return 0;
}