#include "Driver.hpp"

 Driver::Driver(string name, string nationality, float experience)
 : name(name), nationality(nationality), experience(experience) {}

 //setters
 void Driver::setName (string name){
    this->name=name;
}
void Driver::setNationality (string nationality){
    this->nationality=nationality;
}
void Driver::setExperience (float experience){
    this->experience=experience;
}

//getters
string Driver::getName(){
    return name;
}
string Driver::getNationality(){
    return nationality;
}
float Driver::getExperience(){
    return experience;
}
float Driver::skillFactor() {
        return 1.0f + (experience * 0.05f);
    }

void Driver::displayDriverInfo(){
    cout<<"-------------------------"<<endl;
    cout<<"Driver: "<<name<<endl;
    cout<<"Nationality: "<<nationality<<endl;
    cout<<"Experience: "<<experience<<" years"<<endl;
 
 }
