#ifndef TRACK_HPP_INCLUDED
#define TRACK_HPP_INCLUDED

#include <string>
#include <iostream>

using namespace std;

class Track{
    private:
    string name;
    float length;
    int laps;

    public:
    //constructor
    Track(string name, float length, int laps);
    //setters
    void setName (string name);
    void setLength (float length);
    void setLaps (int laps);
    void displayTrackInfo() ;
    //getters
    string getName () ;
    float getLength ();
    int getLaps ();
    float getTotalDistance() ;
};

#endif