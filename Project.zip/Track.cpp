#include "Track.hpp"

//constructor
Track::Track(string name, float length, int laps): name(name), length(length), laps(laps) {}

// Setters
void Track::setName(string name) {
    this->name = name;
}

void Track::setLength(float length) {
    this->length = length;
}

void Track::setLaps(int laps) {
    this->laps = laps;
}

// Getters
string Track::getName() {
    return name;
}

float Track::getLength() {
    return length;
}

int Track::getLaps() {
    return laps;
}
   void Track::displayTrackInfo() {
    cout << "Track: " << name << ", Length: " << length << " km, Laps: " << laps << endl;
}

    float Track::getTotalDistance() {
    return length * laps;
}
