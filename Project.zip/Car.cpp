#include "Car.hpp"

Car::Car(string tires, string wings, float power): tires(tires), wings(wings), power(power) {}

//setters
void Car::setTires(string tires){
    this->tires=tires;
}
void Car::setWings(string wings){
    this->wings=wings;
}
void Car::setPower(float power){
    this->power=power;
}
//getters

string Car::getTires(){
    return tires;
}
string Car::getWings(){
    return wings;
}
float Car::getPower(){
    return power;
}

void Car::displayCarInfo(){
    cout<<"-------------------------"<<endl;
    cout<<"Car power: "<<power<<"HP"<<endl;
    cout<<"Wings: "<<wings<<endl;
    cout<<"Tires: "<<tires<<endl;
}

float Car::getPerformanceFactor() {
        return power* 0.00001f;
    }
