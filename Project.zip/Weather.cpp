#include "Weather.hpp"

Weather::Weather(string condition, float temperature)
: condition(condition), temperature(temperature) {}

//setters
void Weather::setCondition(string condition){
    this->condition=condition;
}
void Weather::setTemperature(float temperature){
    this->temperature=temperature;
}
//getters

string Weather::getCondition(){
    return condition;
}
float Weather::getTemperature(){
    return temperature;
}

void Weather::displayWeatherInfo(){
     cout<<"-------------------------"<<endl;
    cout << "Weather: " << condition << ", Temperature: " << temperature <<"ºC"<<endl;
}

float Weather::impactOnSpeed() {
    string condition;
        if (condition == "Rainy") {
            return 0.6f;
        } else if (condition == "Sunny") {
            return 1.0f;
        } else {
            return 0.9f;
        }
    }